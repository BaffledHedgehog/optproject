Compile article.tex three times with xelatex. No scientific rerun is needed. See the full reading packet for code and evidence.
