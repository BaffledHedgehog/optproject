"""Package existing v19 PDFs, proofs and evidence without scientific reruns.

The archives have sorted entries, fixed timestamps and fixed permissions.
Every archive is checked for CRC, exact file names and byte-for-byte content.
No experiment, symbolic audit or LaTeX compilation is executed here.
"""

from pathlib import Path, PurePosixPath
import hashlib
import io
import json
import re
import zipfile


ROOT = Path(__file__).resolve().parent
TEX_NAMES = (
    "article.tex", "model.tex", "step.tex", "rates.tex",
    "examples.tex", "experiments.tex", "references.tex",
)
ZIP_TIMESTAMP = (2026, 11, 12, 0, 0, 0)


def require(condition, message):
    if not condition:
        raise RuntimeError(message)


def sha256(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def json_bytes(value):
    return (json.dumps(value, indent=2, ensure_ascii=False) + "\n").encode("utf-8")


def verify_zip(data, entries):
    with zipfile.ZipFile(io.BytesIO(data)) as archive:
        require(archive.testzip() is None, "ZIP CRC check failed")
        require(len(archive.namelist()) == len(entries), "Unexpected or duplicate ZIP entries")
        require(set(archive.namelist()) == set(entries), "ZIP file list mismatch")
        for name, expected in entries.items():
            require(archive.read(name) == expected, f"ZIP content mismatch: {name}")


def zip_bytes(entries):
    buffer = io.BytesIO()
    with zipfile.ZipFile(buffer, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
        for name, data in sorted(entries.items()):
            path = PurePosixPath(name)
            require(not path.is_absolute() and ".." not in path.parts,
                    f"Unsafe archive path: {name}")
            info = zipfile.ZipInfo(name, ZIP_TIMESTAMP)
            info.create_system = 3
            info.compress_type = zipfile.ZIP_DEFLATED
            info.external_attr = 0o100644 << 16
            archive.writestr(info, data, compress_type=zipfile.ZIP_DEFLATED, compresslevel=9)
    result = buffer.getvalue()
    verify_zip(result, entries)
    return result


def write_zip(path, entries):
    data = zip_bytes(entries)
    require(data == zip_bytes(entries), f"Archive generation was not deterministic: {path.name}")
    path.write_bytes(data)
    verify_zip(path.read_bytes(), entries)


def verify_tex_dependencies(entries, figure_name):
    inputs, graphics = set(), set()
    for name in TEX_NAMES:
        text = entries[name].decode("utf-8")
        for target in re.findall(r"\\(?:input|include)\s*\{([^}]+)\}", text):
            target = str(PurePosixPath(target))
            if not PurePosixPath(target).suffix:
                target += ".tex"
            require(target in entries, f"Missing TeX input {target} from {name}")
            inputs.add(target)
        for target in re.findall(r"\\includegraphics\s*(?:\[[^\]]*\]\s*)?\{([^}]+)\}", text):
            target = str(PurePosixPath(target))
            candidates = [target] if PurePosixPath(target).suffix else [target + suffix for suffix in (".pdf", ".png", ".jpg", ".jpeg")]
            matches = [candidate for candidate in candidates if candidate in entries]
            require(bool(matches), f"Missing figure {target} from {name}")
            graphics.update(matches)
    require(figure_name in graphics, f"Expected figure is not referenced: {figure_name}")
    require(set(TEX_NAMES) - {"article.tex"} <= inputs, "The article does not include every required proof section")
    return {"tex_inputs": sorted(inputs), "figures": sorted(graphics)}


def source_archive(language):
    source = ROOT / "Paper" / ("ru" if language == "ru" else "")
    entries = {name: (source / name).read_bytes() for name in TEX_NAMES}
    if language == "ru":
        entries["experiments.tex"] = entries["experiments.tex"].replace(b"../figures/", b"figures/")
    figure = f"figures/gap_benchmark_{language}.pdf"
    entries[figure] = (ROOT / "Paper" / figure).read_bytes()
    checks = verify_tex_dependencies(entries, figure)
    engine = "xelatex" if language == "ru" else "pdflatex"
    note = (
        "v19 LaTeX source archive, 12 November 2026.\n"
        f"Compile article.tex with {engine} three times.\n"
        "All input sections and the required PDF figure are included.\n"
        "LaTeX does not run the numerical experiment or symbolic checks.\n"
    )
    if language == "ru":
        note += (
            "Needs fontspec, polyglossia, Liberation Serif/Sans and DejaVu Sans Mono.\n"
            "Only the archived experiments.tex has its figure path normalized\n"
            "from ../figures/ to figures/. The release source remains unchanged.\n"
        )
    entries["BUILD.txt"] = note.encode("utf-8")
    filename = "arxiv_source_ru_v19.zip" if language == "ru" else "arxiv_source_v19.zip"
    write_zip(ROOT / filename, entries)
    return filename, checks


def verify_build_receipt(language):
    folder = ROOT / "Paper" / ("ru" if language == "ru" else "")
    receipt = json.loads((folder / "build_receipt.json").read_text(encoding="utf-8"))
    require(receipt["release"] == "v19" and receipt["language"] == language,
            f"Wrong build receipt for {language}")
    require(not receipt["source_changed_during_build"], f"Sources changed during the {language} build")
    require(len(receipt["passes"]) == 3 and all(row["exit"] == 0 for row in receipt["passes"]),
            f"The {language} build did not complete all three passes")
    require(set(receipt["source_hashes"]) == set(TEX_NAMES), f"Incomplete {language} source manifest")
    for name, expected in receipt["source_hashes"].items():
        require(sha256(folder / name) == expected, f"Source changed after the {language} build: {name}")
    require(not any("overfull" in line.lower() for line in receipt["warning_lines"]),
            f"Overfull text remains in the {language} build")
    return {
        "passes": 3, "all_passes_succeeded": True,
        "source_hashes_match": True, "warning_lines": receipt["warning_lines"],
        "scientific_calls": receipt.get("scientific_calls", 0),
        "source_hashes": receipt["source_hashes"],
    }


def main():
    validation_path = ROOT / "Evidence/release_validation.json"
    validation = json.loads(validation_path.read_text(encoding="utf-8"))
    validation["build"] = {language: verify_build_receipt(language) for language in ("en", "ru")}
    for source, target in (("Paper/paper.pdf", "paper.pdf"), ("Paper/ru/paper_ru.pdf", "paper_ru.pdf")):
        content = (ROOT / source).read_bytes()
        require(content.startswith(b"%PDF-"), f"Not a PDF: {source}")
        (ROOT / target).write_bytes(content)
        require((ROOT / target).read_bytes() == content, f"PDF copy mismatch: {target}")

    sources, dependency_checks = [], {}
    for language in ("en", "ru"):
        filename, checks = source_archive(language)
        sources.append(filename)
        dependency_checks[language] = checks

    validation["status"] = "passed"
    validation["archive_checks"] = {
        "status": "passed", "source_archives": sources,
        "reading_packet": "reading_packet_v19.zip",
        "source_crc_and_content_match": True,
        "reading_crc_and_content_match": True,
        "deterministic_bytes_checked": True,
        "fixed_timestamp": "2026-11-12 00:00:00",
        "tex_dependencies": dependency_checks,
        "ru_figure_path_normalized": True,
        "final_pdf_copies_match": True,
        "all_proof_sections_in_reading_packet": True,
        "scientific_runs_during_packaging": 0,
        "latex_builds_during_packaging": 0,
    }
    critical_files = (
        "paper.pdf", "paper_ru.pdf", "guide_professor.txt", "README.md", "README_RU.txt",
        "CHANGES_v19.txt", "ARXIV_METADATA.txt", "build_papers.py", "package_release.py",
        "Code/benchmark_gap.py", "Code/check_algebra.py",
        "Evidence/independent_review.txt", "Evidence/algebra_audit.txt",
        "Evidence/gap_summary.json", "Evidence/gap_checks.json",
        "Evidence/gap_summary.csv", "Evidence/gap_trace.csv", *sources,
    )
    validation["sha256"] = {name: sha256(ROOT / name) for name in critical_files}
    validation_content = json_bytes(validation)

    names = [
        "paper.pdf", "paper_ru.pdf", "guide_professor.txt", "README.md", "README_RU.txt",
        "CHANGES_v19.txt", "ARXIV_METADATA.txt", "build_papers.py", "package_release.py", *sources,
    ]
    for folder, patterns in (("Code", ("*.py", "*.txt")), ("Evidence", ("*.json", "*.csv", "*.txt"))):
        for pattern in patterns:
            names.extend(path.relative_to(ROOT).as_posix() for path in sorted((ROOT / folder).glob(pattern)))
    for language in ("en", "ru"):
        prefix = "Paper/ru/" if language == "ru" else "Paper/"
        names.extend(prefix + name for name in TEX_NAMES)
        names.append(prefix + "build_receipt.json")
    names.extend(path.relative_to(ROOT).as_posix() for path in sorted((ROOT / "Paper/figures").glob("*")) if path.is_file())
    names = sorted(set(names))
    require("paper.pdf" in names and "paper_ru.pdf" in names, "Final PDFs are missing from the reading packet")
    require(all(prefix + name in names for prefix in ("Paper/", "Paper/ru/") for name in TEX_NAMES),
            "Proof sections are missing from the reading packet")
    entries = {name: (ROOT / name).read_bytes() for name in names}
    entries["Evidence/release_validation.json"] = validation_content
    manifest = {name: hashlib.sha256(data).hexdigest() for name, data in entries.items()}
    entries["SHA256SUMS.json"] = json_bytes(manifest)

    # Verify the completed candidate, including its final validation report,
    # before persisting the report and the reading packet.
    reading_data = zip_bytes(entries)
    require(reading_data == zip_bytes(entries), "Reading packet generation was not deterministic")
    validation_path.write_bytes(validation_content)
    reading_path = ROOT / "reading_packet_v19.zip"
    reading_path.write_bytes(reading_data)
    verify_zip(reading_path.read_bytes(), entries)
    with zipfile.ZipFile(reading_path) as archive:
        recorded = json.loads(archive.read("SHA256SUMS.json"))
        require(recorded == manifest, "Reading packet manifest mismatch")
        for name, expected in recorded.items():
            require(hashlib.sha256(archive.read(name)).hexdigest() == expected,
                    f"Reading packet hash mismatch: {name}")

    for name in ("paper.pdf", "paper_ru.pdf", *sources, "reading_packet_v19.zip"):
        path = ROOT / name
        print(f"{name}: {path.stat().st_size} bytes; SHA256 {sha256(path)}")
    print("Verified: build-source hashes; all TeX inputs and figures; deterministic ZIP bytes; CRC and exact content; reading manifest.")


if __name__ == "__main__":
    main()
