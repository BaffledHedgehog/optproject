# Frank-Wolfe under gap-dependent smoothness

Revision v19, 12 November 2026. Authors: Yaroslav P. Lyakhov and Stepan A. Suvorov.

- [English paper](paper.pdf) and [Russian paper](paper_ru.pdf).
- [Russian paragraph-by-paragraph guide](guide_professor.txt).
- [Release instructions](README_RU.txt) and [changes after the review](CHANGES_v19.txt).
- [Code instructions](Code/README.txt), [numerical protocol](Evidence/gap_summary.json), and [independent review](Evidence/independent_review.txt).
- [Complete reading packet](reading_packet_v19.zip).
- [English LaTeX](arxiv_source_v19.zip) and [Russian LaTeX](arxiv_source_ru_v19.zip).

The curvature model bounds the Hessian by L0 + L1 G(x), where G is the full
Frank-Wolfe gap on the feasible set. The objective is quasar-convex;
ordinary convexity is the special case gamma = 1.

The paper derives gap transport, an exponential upper model, and a
computable logarithmic step. It proves finite stopping with complete
operation counts, geometric convergence for L0 = 0, and a linear rate
on strongly convex sets with a nonzero gradient at the minimizer.
Neither the minimum nor its value is an input to the algorithm.

For exp(x)+A*y on [0,R] x [0,1], the same gap-dependent constants
L0 = L1 = 1 work for every R,A > 0. The best uniform Hessian bound is
L = exp(R). From (R,0), the logarithmic rule reaches the exact minimum
in O(R²) updates, while the ordinary short step with this best uniform
constant requires Omega(exp(R)) updates at fixed accuracy.

All 24 fixed numerical runs passed. An independent instrumented rerun
reproduced the four result files byte for byte and verified N+1 actual
calls to each of the objective, gradient, and full linear minimization.
Thirteen scalar identities were checked symbolically. These checks are
distinct from formal Lean certification.

Commands and dependencies are listed in Code/README.txt.
The PDF build does not run experiments.

[v18](../2026-11-12-v18/README_RU.txt) is preserved as a separate intermediate
release. The attached November 1 manuscript is a historical reference.
This is a research manuscript; no journal or arXiv submission has been performed.
